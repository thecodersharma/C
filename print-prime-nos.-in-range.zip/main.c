#include <stdio.h>

int main() {
    int n;
    printf("Enter an upper limit: ");
    scanf("%d", &n);

    for (int i = 2; i <= n; i++) {   // This loop will go only up to 'n'
        int isPrime = 1;             // Assume the number is prime

        for (int j = 2; j * j <= i; j++) {  // Check for factors up to sqrt(i)
            if (i % j == 0) {        // If i is divisible by j, it's not prime
                isPrime = 0;
                break;
            }
        }

        if (isPrime) {               // If no divisors were found, print the number
            printf("%d ", i);
        }
    }
    printf("\n");

    return 0;
}
