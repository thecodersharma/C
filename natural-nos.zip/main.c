#include <stdio.h>
int fib(int n);

int main()
{int n;
    printf("enter a number:",n);
    scanf("%d",&n);
if(n==1 || n>1){
    printf("this number is a natural number");
    
}
else {
    printf("this number is not a natural no");
}
    return 0;
    
}